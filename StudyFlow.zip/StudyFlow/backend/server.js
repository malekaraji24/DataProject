const express = require('express');
const cors = require('cors');
require('dotenv').config();

const connectDB = require('./config/database');
const authRoutes = require('./routes/auth');
const auth = require('./middleware/auth');
const coursesRoutes = require('./routes/courses');
const app = express();
const tasksRoutes = require('./routes/tasks');

connectDB();

app.use(cors());
app.use(express.json());
app.use('/api/tasks', tasksRoutes);

app.use('/api/auth', authRoutes);
app.use('/api/courses', coursesRoutes);
app.get('/api/protected', auth, (req, res) => {
  res.json({
    message: 'Access granted',
    user: req.user
  });
});

app.get('/', (req, res) => {
  res.json({ message: 'StudyFlow API is running!' });
});

app.get('/api/health', (req, res) => {
  res.json({
    status: 'OK',
    message: 'StudyFlow API is healthy',
    timestamp: new Date().toISOString()
  });
});

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});